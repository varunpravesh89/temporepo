package com.example.myhostel;

import static com.example.myhostel.R.id.signup_email;
import static com.example.myhostel.R.id.signup_roll;
import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Button;
import android.os.Bundle;
import com.example.myhostel.R;
        import android.widget.EditText;
        import android.widget.Toast;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
import java.util.Calendar;


public class SignUpActivity extends AppCompatActivity {


    FirebaseDatabase rootNode= FirebaseDatabase.getInstance();
    DatabaseReference reff= rootNode.getReference("Member");
    Member member;

    /*String[] item= {"Veg", "Non Veg"};
    AutoCompleteTextView autoCompleteTextView;
    ArrayAdapter<String> adapterItems;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        EditText signupPassword = (EditText)findViewById(R.id.signup_password);

        EditText signupName = (EditText)findViewById(R.id.signup_name);
        EditText signupRoll = (EditText)findViewById(R.id.signup_roll);
        EditText signupPhone = (EditText)findViewById(R.id.signup_phone);
        EditText signupDept = (EditText)findViewById(R.id.signup_dept);
        EditText signupAdd = (EditText)findViewById(R.id.signup_add);
        EditText signupMess = (EditText)findViewById(R.id.signup_mess);
        Button signupButton = (Button)findViewById(R.id.signup_button);
        TextView loginRedirectText = findViewById(R.id.loginRedirectText);
        EditText dateEdt = findViewById(R.id.signup_dob);
        EditText signupEmail = (EditText)findViewById(signup_email) ;


      /*  autoCompleteTextView= findViewById(R.id.signup_mess);
        adapterItems= new ArrayAdapter<String>(this,R.layout.list_item, item);
        autoCompleteTextView.setAdapter(adapterItems);
        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String item =adapterView.getItemAtPosition(i).toString();
                Toast.makeText(SignUpActivity.this, "Mess"+item, Toast.LENGTH_SHORT).show();
            }
        });
*/

        member=new Member();


        dateEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        // on below line we are passing context.
                        SignUpActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                dateEdt.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                            }
                        },

                        year, month, day);

                datePickerDialog.show();
            }
        });



        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {




                int phonenum=Integer.parseInt(signupPhone.getText().toString().trim());
                member.setEmail(signupEmail.getText().toString().trim());
                member.setPassword(signupPassword.getText().toString().trim());
                member.setName(signupName.getText().toString().trim());
                member.setPhoneNum(phonenum);
                member.setDepartment(signupDept.getText().toString().trim());
                member.setAddress(signupAdd.getText().toString().trim());
                member.setDOB(dateEdt.getText().toString().trim());
                member.setMess(signupMess.getText().toString().trim());
                member.setRoll(signupRoll.getText().toString().trim());



                if (member.getEmail().isEmpty()){
                    signupEmail.setError("Email cannot be empty");
                }
                if (member.getRoll().isEmpty()){
                    signupRoll.setError("Register Number cannot be empty");
                }

                if (member.getPassword().isEmpty()) {
                    signupPassword.setError("Password cannot be empty");
                }
                if (member.getName().isEmpty()){
                    signupName.setError("Name cannot be empty");
                }
                if (member.getDepartment().isEmpty()) {
                    signupDept.setError("Department Number cannot be empty");
                }
                if (member.getAddress().isEmpty()) {
                    signupAdd.setError("Address cannot be empty");
                }
                if (member.getMess().isEmpty()) {
                    signupMess.setError("Mess Number cannot be empty");
                }

                else {
                    reff.child(member.getRoll()).setValue(member);
                    Toast.makeText(SignUpActivity.this, "Your Response has Been Submitted", Toast.LENGTH_LONG).show();

                   signupEmail.setText("");
                   signupPhone.setText("\0");
                    signupName.setText("");
                    signupDept.setText("");
                    signupAdd.setText("");
                    signupMess.setText("");
                    signupPassword.setText("");
                    signupRoll.setText("");
                    dateEdt.setText("");

                }



            }
        });
        loginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

    }

}

