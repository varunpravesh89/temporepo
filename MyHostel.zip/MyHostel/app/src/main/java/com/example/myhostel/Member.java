package com.example.myhostel;

public class Member {
    private Integer PhoneNum;
    private String Name;
    private String Roll;
    private String Email;
    private String Password;
    private String Department;
    private String Address;
    private String DOB;
    private String Mess;
    private Integer RoomNo;
    private String Complaint;
    private String Block;
    public Integer getPhoneNum() {
        return PhoneNum;
    }
    public void setPhoneNum(Integer phoneNum) {
        PhoneNum = phoneNum;
    }
    public String getName() {
        return Name;
    }


    public String getRoll() {
        return Roll;
    }

    public void setName(String name) {
        Name = name;
    }
    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
    public void setRoll(String roll) {
        Roll= roll;
    }



    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getMess() {
        return Mess;
    }

    public void setMess(String mess) {
        Mess = mess;
    }

    public Integer getRoomNo() {
        return RoomNo;
    }

    public void setRoomNo(Integer roomNo) {
        RoomNo = roomNo;
    }

    public String getComplaint() {
        return Complaint;
    }

    public void setComplaint(String complaint) {
        Complaint = complaint;
    }

    public String getBlock() {
        return Block;
    }

    public void setBlock(String block) {
        Block = block;
    }


}

