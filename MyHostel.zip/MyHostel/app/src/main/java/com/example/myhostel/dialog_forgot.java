package com.example.myhostel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dialog_forgot extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_forgot);
    }
}

